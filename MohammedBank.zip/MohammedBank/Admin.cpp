#include "Admin.h"
Admin* Admin::instance = nullptr;