#include "GlobalVectors.h"
std::vector<Client*> clientList;
std::vector<Employee*> employeeList;
std::vector<Admin*> adminList;