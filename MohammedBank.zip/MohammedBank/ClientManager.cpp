#include "ClientManager.h"
int ClientManager::currentClientId = 0;