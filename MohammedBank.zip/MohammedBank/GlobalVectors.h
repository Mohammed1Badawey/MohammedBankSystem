#pragma once
#include <vector>
class Admin;
class Employee;
class Client;

extern std::vector<Client*> clientList;
extern std::vector<Employee*> employeeList;
extern std::vector<Admin*> adminList;
class GlobalVectors
{
};

